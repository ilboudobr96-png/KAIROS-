// api/claude.js — Vercel Serverless Function
// KAIROS Resilience Hub · Autore: Bernard Ilboudo
// Questo file gira sul SERVER di Vercel — la API key non è mai esposta al browser

export default async function handler(req, res) {
  // CORS — permetti richieste dal tuo dominio
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Metodo non consentito' });
  }

  // Legge la API key dalle variabili d'ambiente di Vercel (sicuro)
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'API key non configurata. Vai su Vercel → Settings → Environment Variables e aggiungi ANTHROPIC_API_KEY' });
  }

  try {
    const body = req.body;

    // Chiama Anthropic server-side
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-beta': 'web-search-2025-03-05',
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json(data);
    }

    return res.status(200).json(data);
  } catch (err) {
    console.error('Errore chiamata Anthropic:', err);
    return res.status(500).json({ error: err.message });
  }
}
